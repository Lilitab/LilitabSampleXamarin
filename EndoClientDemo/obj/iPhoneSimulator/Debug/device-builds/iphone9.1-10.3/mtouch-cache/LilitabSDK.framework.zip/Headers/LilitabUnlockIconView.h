//
//  LilitabUnlockIconView.h
//  LilitabSDK
//
//  Created by Kevin Snow on 7/30/16.
//  Copyright © 2016-2017 Lilitab. All rights reserved.
//

#import <UIKit/UIKit.h>

IB_DESIGNABLE

    // A view that draws a lock image reflecting current dock lock state 

@interface LilitabUnlockIconView : UIView
@end
