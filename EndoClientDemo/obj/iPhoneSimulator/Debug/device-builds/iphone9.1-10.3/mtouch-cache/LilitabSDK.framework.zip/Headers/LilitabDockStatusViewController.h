//
//  LilitabDockStatusViewController.h
//  LilitabSDK
//
//  Created by Kevin Snow on 7/31/16.
//  Copyright © 2016-2017 Lilitab. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LilitabDockStatusViewController : UIViewController

-(void) copyFieldsToPasteboard;

@end
